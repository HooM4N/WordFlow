import os, torch
from argparse import ArgumentParser
from torch.utils.data import DataLoader

import src.dataset as wf_dataset 
from src.config import resolve_device, read_config, ensure_dirs, model_summary
from src.data import get_data, train_val_split
from src.tokenizer import Tokenizer
from src.model import WordFlowModel, detach_hidden
from src.pretrained_embeddings import get_glove_embeddings
from src.trainer import trainer

def get_args():
    parser = ArgumentParser(description="*** WordFlow: Word-Level Language Modeling with RNNs ***")
    parser.add_argument("--config_path", type=str, default="config/config.yaml",
                        help="path to config file (yaml)")
    parser.add_argument("--training_mode", choices=["bptt", "sliding", "varlen"], default=None,
                        help=("training modes 'bptt' (Truncated BPTT), 'sliding'" 
                              "(Sliding Sequence Windows) or 'varlen' (Variable Lenght Sequences)"))
    parser.add_argument("--n_epochs", type=int, default=None,
                        help="number of training epochs")
    parser.add_argument("--batch_size", type=int, default=None,
                        help="training batch size")
    parser.add_argument("--use_accelerator", type=bool, default=None,
                        help="use available accelerator or cpu")
    parser.add_argument("--seed", type=int, default=None,
                        help="random seed")
    parser.add_argument("--dry_run", action="store_true",
                        help="run one step of training for testing")
    return parser.parse_args()

def train(config):
    #=======================#
    #     Configuration     #
    #=======================#
    # validate_config(config)
    device = resolve_device(config["use_accelerator"])
    ensure_dirs(config)
    
    #======================#
    #     Prepare Data     #
    #======================#
    train_corpus = get_data(
        config["train_data_path"],
        **config["get_data_params"],
        random_seed = config["seed"],
    )
    evaluate = False
    
    if config["val_data_path"] is not None:
        val_corpus = get_data(config["val_data_path"])
        evaluate = True
        
    elif config["do_val_split"]:
        train_corpus, val_corpus = train_val_split(
            train_corpus, 
            config["val_split_ratio"], 
            config["val_split_shuffle"],
            config["seed"]
        )
        evaluate = True
        
    #======================#
    #     Tokenization     #
    #======================#        
    tokenizer = Tokenizer(
        max_tokens = config["max_vocab_size"], 
        lowercase = config["tokenizer_lowercase"]
    )
    tokenizer.build_vocab(train_corpus)
    train_ids = [tokenizer.encode(d) for d in train_corpus]
    
    if evaluate:
        val_ids = [tokenizer.encode(d) for d in val_corpus]
    
    #============================#
    #     Prepare DataLoader     #
    #============================#
    modes = {
        "bptt": {
            "class": "TruncatedBPTTDataset",
            "args": ["batch_size", "seq_len"],
            "collate": "bptt_collate"
            },
        "sliding": {
            "class": "SlidingWindowDataset",
            "args": ["seq_len", "min_seq_len"],
            "collate": "sliding_collate"
        },
        "varlen": {
            "class": "VariableLengthDataset",
            "args": ["seq_len"],
            "collate": "varlen_collate"
        },
    }
    train_ds = getattr(wf_dataset, modes[config["training_mode"]]["class"])(
        train_ids, **{k:config[k] for k in modes[config["training_mode"]]["args"]}
    )
    train_ds.print_info()
    
    train_loader = DataLoader(
        train_ds, 
        batch_size = 1 if config["training_mode"] == "bptt" else config["batch_size"], 
        shuffle = False if config["training_mode"] == "bptt" else True,
        pin_memory = True, 
        collate_fn = getattr(wf_dataset, modes[config["training_mode"]]["collate"])
    )
    
    if evaluate:
        val_ds = getattr(wf_dataset, modes[config["training_mode"]]["class"])(
            val_ids, **{k:config[k] for k in modes[config["training_mode"]]["args"]}
        )
        val_loader = DataLoader(
            val_ds, 
            batch_size = 1 if config["training_mode"] == "bptt" else config["batch_size"], 
            shuffle = False,
            pin_memory = True, 
            collate_fn = getattr(wf_dataset, modes[config["training_mode"]]["collate"])
        )
        
    #===========================#
    #     Instantiate Model     #
    #===========================#
    
    if config["use_glove_embeddings"]:
        try:
            print(f"*** loading pretrained GloVe word embeddings ***")
            pretrained_embeddings = get_glove_embeddings(
                config["glove_embeddings_path"], config["glove_dim"], tokenizer.get_vocab()
            )
            pretrained_embeddings = torch.tensor(pretrained_embeddings, dtype=torch.float32)
        except Exception as e:
            print(f"*** failed to load pretrained embedding matrix. initializing with random values: {e} ***")
        
    torch.manual_seed(config["seed"])
    model = WordFlowModel(
        tokenizer.get_vocab_size(), 
        **config["model_params"], 
        pretrained_embedding_matrix = pretrained_embeddings if config["use_glove_embeddings"] else None
    ).to(device)
    
    print(model_summary(model))
    
    #=======================#
    #     Training Loop     #
    #=======================#
    loss_fn = torch.nn.CrossEntropyLoss(
        ignore_index = tokenizer.token_to_id("<pad>")
    )
    optimizer = torch.optim.NAdam(
        model.parameters(), **config["optimizer_params"]
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, **config["lr_scheduler_params"]
    )
    
    model = trainer(
        model, optimizer, config, device, scheduler,
        detach_hidden, train_loader, loss_fn, tokenizer,
        val_loader = val_loader if evaluate else None
    )
    
if __name__ == "__main__":
    ## GET CLI ARGS ##
    args = get_args()
    ## READ CONFIG FILE ##
    config = read_config(args.config_path)
    ## OVERRIDE CONFIG WITH CLI ARGS ##
    for key in [
        "training_mode", "n_epochs", "batch_size", "use_accelerator", "seed", "dry_run"
    ]:
        val = getattr(args, key)
        if val is not None:
            config[key] = val
    ## TRAINING PROCESS ##
    train(config)